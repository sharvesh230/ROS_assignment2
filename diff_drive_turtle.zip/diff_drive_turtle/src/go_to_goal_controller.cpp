#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Pose2D.h>
#include <turtlesim/Pose.h>
#include "diff_drive_turtle/WheelVel.h"
#include <cmath>

static double normalizeAngle(double a) {
  while (a > M_PI) a -= 2.0*M_PI;
  while (a < -M_PI) a += 2.0*M_PI;
  return a;
}

class GoToGoal {
public:
  GoToGoal() {
    ros::NodeHandle pnh("~");

    // Robot params
    pnh.param("wheel_radius", wheel_radius_, 0.05);
    pnh.param("wheel_base", wheel_base_, 0.20);

    // Controller gains
    pnh.param("K_rho", K_rho_, 1.5);
    pnh.param("K_alpha", K_alpha_, 4.0);
    pnh.param("K_beta",  K_beta_, -1.0);

    pnh.param("pos_tol", pos_tol_, 0.05);
    pnh.param("theta_tol", theta_tol_, 0.05);

    // Default goal
    pnh.param("goal_x", goal_.x, 5.5);
    pnh.param("goal_y", goal_.y, 5.5);
    pnh.param("goal_theta", goal_.theta, 0.0);

    pose_sub_ = nh_.subscribe("/turtle1/pose", 10, &GoToGoal::poseCb, this);
    goal_sub_ = nh_.subscribe("/goal_pose", 10, &GoToGoal::goalCb, this);

    cmd_pub_ = nh_.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 10);
    wheel_pub_ = nh_.advertise<diff_drive_turtle::WheelVel>("wheel_vel_dbg", 10);

    timer_ = nh_.createTimer(ros::Duration(0.05), &GoToGoal::controlLoop, this);

    got_pose_ = false;
  }

private:
  void goalCb(const geometry_msgs::Pose2D::ConstPtr& msg) {
    goal_ = *msg;
    ROS_INFO("New goal received: %.2f %.2f %.2f", goal_.x, goal_.y, goal_.theta);
  }

  void poseCb(const turtlesim::Pose::ConstPtr& msg) {
    current_x_ = msg->x;
    current_y_ = msg->y;
    current_theta_ = msg->theta;
    got_pose_ = true;
  }

  void controlLoop(const ros::TimerEvent&) {
    if (!got_pose_) return;

    double dx = goal_.x - current_x_;
    double dy = goal_.y - current_y_;
    double rho = sqrt(dx*dx + dy*dy);

    double angle_to_goal = atan2(dy, dx);
    double alpha = normalizeAngle(angle_to_goal - current_theta_);
    double beta  = normalizeAngle(goal_.theta - current_theta_ - alpha);

    double v = 0.0;
    double w = 0.0;

    if (rho > pos_tol_) {
      v = K_rho_ * rho;
      w = K_alpha_ * alpha + K_beta_ * beta;
    } else {
      double t_diff = normalizeAngle(goal_.theta - current_theta_);
      if (fabs(t_diff) > theta_tol_) {
        v = 0.0;
        w = 2.0 * t_diff;
      } else {
        v = 0.0;
        w = 0.0;
      }
    }

    geometry_msgs::Twist cmd;
    cmd.linear.x = v;
    cmd.angular.z = w;
    cmd_pub_.publish(cmd);

    // Inverse Kinematics
    diff_drive_turtle::WheelVel wheels;
    wheels.omega_right = (v + (wheel_base_/2.0)*w) / wheel_radius_;
    wheels.omega_left  = (v - (wheel_base_/2.0)*w) / wheel_radius_;
    wheel_pub_.publish(wheels);
  }

  ros::NodeHandle nh_;
  ros::Subscriber pose_sub_, goal_sub_;
  ros::Publisher cmd_pub_, wheel_pub_;
  ros::Timer timer_;

  double current_x_, current_y_, current_theta_;
  bool got_pose_;

  geometry_msgs::Pose2D goal_;

  double wheel_radius_, wheel_base_;
  double K_rho_, K_alpha_, K_beta_;
  double pos_tol_, theta_tol_;
};

int main(int argc, char** argv) {
  ros::init(argc, argv, "go_to_goal_controller");
  GoToGoal g;
  ros::spin();
  return 0;
}

