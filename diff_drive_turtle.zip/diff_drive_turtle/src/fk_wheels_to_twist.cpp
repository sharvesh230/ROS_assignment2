#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include "diff_drive_turtle/WheelVel.h"

class FKNode {
public:
  FKNode() {
    ros::NodeHandle pnh("~");
    pnh.param("wheel_radius", wheel_radius_, 0.05);
    pnh.param("wheel_base", wheel_base_, 0.20);

    sub_ = nh_.subscribe("wheel_vel_in", 10, &FKNode::wheelCb, this);
    pub_ = nh_.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 10);
  }

private:
  void wheelCb(const diff_drive_turtle::WheelVel::ConstPtr& msg) {
    double omega_l = msg->omega_left;
    double omega_r = msg->omega_right;

    // Forward Kinematics equations
    // v = r/2 * (wr + wl)
    // w = r/L * (wr - wl)
    geometry_msgs::Twist twist;
    twist.linear.x  = wheel_radius_ / 2.0 * (omega_r + omega_l);
    twist.angular.z = wheel_radius_ / wheel_base_ * (omega_r - omega_l);

    pub_.publish(twist);
  }

  ros::NodeHandle nh_;
  ros::Subscriber sub_;
  ros::Publisher pub_;
  double wheel_radius_;
  double wheel_base_;
};

int main(int argc, char** argv) {
  ros::init(argc, argv, "fk_wheels_to_twist");
  FKNode node;
  ros::spin();
  return 0;
}

